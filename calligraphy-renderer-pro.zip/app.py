# calligraphy-renderer-pro / app.py
from flask import Flask, request, send_file, jsonify, Response
import io, os
import gi
gi.require_version("Pango", "1.0")
gi.require_version("PangoCairo", "1.0")
from gi.repository import Pango, PangoCairo, cairo
from PIL import Image, ImageFilter, ImageOps
import numpy as np

app = Flask(__name__)

FONT_STACKS = {
    "naskh":    "Amiri Quran, Amiri, Noto Naskh Arabic, Scheherazade New",
    "ruqah":    "Aref Ruqaa, Aref Ruqaa Ink, Amiri, Noto Naskh Arabic",
    "kufi":     "Reem Kufi, Noto Kufi Arabic, Amiri",
    "thuluth":  "KFGQPC Thuluth, Amiri, Noto Naskh Arabic",
    "diwani":   "Diwani Letter, Diwani, Amiri, Noto Naskh Arabic",
    "nastaliq": "Noto Nastaliq Urdu, Amiri, Noto Naskh Arabic"
}

def _pango_layout(ctx, text, script, size_pt, width_px, padding_px, rtl):
    layout = PangoCairo.create_layout(ctx)
    fontdesc = Pango.FontDescription(f"{FONT_STACKS.get(script, FONT_STACKS['naskh'])} {size_pt}")
    layout.set_font_description(fontdesc)
    layout.set_width((width_px - 2*padding_px) * Pango.SCALE)
    layout.set_alignment(Pango.Alignment.RIGHT if rtl else Pango.Alignment.LEFT)
    layout.set_wrap(Pango.WrapMode.WORD_CHAR)
    layout.set_text(text, -1)
    return layout

def render_png(text, script="naskh", size_pt=140, width_px=1800, height_px=800, padding_px=60, rtl=True, rgb=(0,0,0), background_rgb=(255,255,255)):
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, width_px, height_px)
    ctx = cairo.Context(surface)
    ctx.set_source_rgb(background_rgb[0]/255.0, background_rgb[1]/255.0, background_rgb[2]/255.0)
    ctx.paint()
    ctx.set_source_rgb(rgb[0], rgb[1], rgb[2])
    layout = _pango_layout(ctx, text, script, size_pt, width_px, padding_px, rtl)
    _, logical = layout.get_extents()
    text_h = logical.height / Pango.SCALE
    y = (height_px - text_h) / 2.0
    x = padding_px
    ctx.move_to(x, y)
    PangoCairo.show_layout(ctx, layout)
    buf = io.BytesIO()
    surface.write_to_png(buf)
    buf.seek(0)
    return buf

def _inkify(png_bytes, paper_tone=0.985, grain_strength=0.08, bleed_px=1.2, vignette=0.18):
    img = Image.open(io.BytesIO(png_bytes)).convert("RGBA")
    w, h = img.size
    gray = ImageOps.grayscale(img)
    inv = ImageOps.invert(gray)
    mask = inv.point(lambda p: 255 if p > 20 else 0).filter(ImageFilter.GaussianBlur(bleed_px))
    blurred = img.filter(ImageFilter.GaussianBlur(bleed_px * 0.6))
    img = Image.composite(blurred, img, mask)
    bg = Image.new("RGB", (w, h), (int(255*paper_tone), int(255*paper_tone*0.985), int(255*paper_tone*0.95)))
    img_noalpha = img.convert("RGB")
    base = Image.blend(bg, img_noalpha, 0.96)
    rng = np.random.default_rng()
    noise = (rng.normal(loc=0.0, scale=25, size=(h, w))).astype(np.float32)
    noise_img = Image.fromarray(np.clip(noise + 128, 0, 255).astype('uint8'), mode='L').filter(ImageFilter.GaussianBlur(1.2))
    noise_rgb = Image.merge("RGB", (noise_img, noise_img, noise_img))
    base = Image.blend(base, noise_rgb, grain_strength)
    y_indices, x_indices = np.ogrid[:h, :w]
    cx, cy = w/2.0, h/2.0
    dist = np.sqrt((x_indices - cx)**2 + (y_indices - cy)**2)
    maxd = np.sqrt(cx**2 + cy**2)
    vign = 1.0 - vignette*(dist/maxd)
    vign = np.clip(vign, 0.6, 1.0)
    vign_img = Image.fromarray(np.uint8(vign*255), mode='L')
    base = Image.composite(base.point(lambda p: int(p*0.9)), base, vign_img)
    out = io.BytesIO()
    base.save(out, format="PNG")
    out.seek(0)
    return out

from flask import jsonify

@app.get("/health")
def health():
    return jsonify(ok=True)

@app.post("/render")
def render_endpoint():
    data = request.get_json(force=True, silent=True) or {}
    text = data.get("text", "بسم الله الرحمن الرحيم")
    script = data.get("script", "naskh")
    size_pt = int(data.get("size_pt", 160))
    width_px = int(data.get("width_px", 2000))
    height_px = int(data.get("height_px", 900))
    padding_px = int(data.get("padding_px", 60))
    rtl = bool(data.get("rtl", True))
    rgb = data.get("rgb", [0,0,0])
    if isinstance(rgb, list) and len(rgb)==3:
        rgb_tuple = (float(rgb[0]), float(rgb[1]), float(rgb[2]))
    else:
        rgb_tuple = (0.0, 0.0, 0.0)
    background_rgb = data.get("background_rgb", [255,255,255])
    if isinstance(background_rgb, list) and len(background_rgb)==3:
        bg_tuple = (int(background_rgb[0]), int(background_rgb[1]), int(background_rgb[2]))
    else:
        bg_tuple = (255,255,255)
    png_buf = render_png(text, script, size_pt, width_px, height_px, padding_px, rtl, rgb_tuple, bg_tuple)
    if data.get("inkify", False):
        paper_tone = float(data.get("paper_tone", 0.985))
        grain = float(data.get("grain_strength", 0.08))
        bleed = float(data.get("bleed_px", 1.1))
        vign = float(data.get("vignette", 0.18))
        stylized = _inkify(png_buf.getvalue(), paper_tone, grain, bleed, vign)
        return send_file(stylized, mimetype="image/png", download_name="calligraphy_ink.png")
    return send_file(png_buf, mimetype="image/png", download_name="calligraphy.png")

_PRESETS = {"الله": {"rows":16, "cols":16, "cells":[]},
            "محمد": {"rows":16, "cols":16, "cells":[]},
            "سلام": {"rows":16, "cols":16, "cells":[]}
           }

def _cells_to_svg(cells, rows, cols, cell=20, color="#000"):
    w, h = cols*cell, rows*cell
    rects = "".join(f'<rect x="{c*cell}" y="{r*cell}" width="{cell}" height="{cell}" fill="{color}"/>' for r,c in cells)
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{rects}</svg>'

def _build_presets():
    # الله
    cells = []
    for r in range(1, 14): cells.append((r,7))
    for c in range(4, 11): cells.append((1,c))
    for c in range(6, 9): cells.append((6,c)); cells.append((9,c))
    for c in range(5, 10): cells.append((13,c))
    _PRESETS["الله"]["cells"] = cells
    # محمد
    cells = []
    for r in range(4, 12):
        for c in range(4, 12):
            if r in (4,11) or c in (4,11):
                cells.append((r,c))
    for c in range(12, 15): cells.append((8,c))
    _PRESETS["محمد"]["cells"] = cells
    # سلام
    cells = []
    for r in range(3, 13): cells.append((r,4)); cells.append((r,11))
    for c in range(4, 12): cells.append((3,c))
    for c in range(6, 10): cells.append((8,c))
    _PRESETS["سلام"]["cells"] = cells
_build_presets()

@app.get("/square-kufic/presets")
def square_kufic_presets():
    return jsonify({"supported": list(_PRESETS.keys()),
                    "note": "POST /square-kufic/render with one of the supported words to get an SVG."})

from flask import Response, send_file
@app.post("/square-kufic/render")
def square_kufic_render():
    data = request.get_json(force=True, silent=True) or {}
    word = data.get("word", "").strip()
    color = data.get("fill", "#000000")
    cell = int(data.get("cell", 20))
    if word not in _PRESETS:
        return jsonify(error="Unsupported word for preset demo.", supported=list(_PRESETS.keys())), 400
    rows = _PRESETS[word]["rows"]; cols = _PRESETS[word]["cols"]
    cells = _PRESETS[word]["cells"]
    svg = _cells_to_svg(cells, rows, cols, cell=cell, color=color)
    return Response(svg, mimetype="image/svg+xml")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))