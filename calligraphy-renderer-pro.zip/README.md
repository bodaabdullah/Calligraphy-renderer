# Calligraphy Renderer Pro (Arabic)

**Plain-English overview**
- An online “printer” that **writes Arabic calligraphy** into images on the fly.
- Styles available: **Naskh, Ruq‘ah, Kufi, Thuluth, Diwani, Nastaliq**.
- Optional **paper & ink** look (grain, slight ink bleed, vignette).
- **Square‑Kufic** presets that return clean **SVG** grids for “الله”, “محمد”, “سلام”.

**How it fits your GPT**
- Your GPT sends: text + style (+ options) → gets back a **PNG** (or **SVG** for Square‑Kufic).
- No scraping or web search — a fresh image is generated every time.

## Deploy in simple terms
- Upload this folder to a host that runs the included container setup (e.g., Render.com).  
- When it’s live, visit `/health` to confirm it’s running.  
- Paste `openapi.yaml` into your GPT’s **Actions** settings and point it to your live URL.

## Endpoints (what they do)
- `GET /health` — quick status check.  
- `POST /render` — returns a PNG of your calligraphy with options for size, background, and ink/paper look.  
- `GET /square-kufic/presets` — shows which preset words are supported.  
- `POST /square-kufic/render` — returns an SVG for one of those words (excellent for logos/tiles).

## Fonts
- Preinstalled: Amiri, Aref Ruqaa, Reem Kufi, Noto Naskh Arabic, Noto Kufi Arabic, **Noto Nastaliq Urdu** (for Nastaliq).  
- Thuluth/Diwani quality depends on which fonts you own; you can bake your own TTF/OTF into the image and list them in the style map.

## Tips
- Use **Kufi** or **Square‑Kufic** for logos and geometric compositions.  
- Use **Naskh** for body/verses, **Ruq‘ah** for handwritten vibe, **Thuluth** for big headings (if you provide a good Thuluth font).  
- Turn on **inkify** to add texture and slight bleed for a hand‑made look.
